exception exception_name {
  1: required i8 return
}
